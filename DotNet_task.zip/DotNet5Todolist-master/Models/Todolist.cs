﻿using System;
using System.Collections.Generic;

#nullable disable

namespace DotNet5Crud.Models
{
    public partial class Todolist
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Details { get; set; }         
        public DateTime LastUpdate { get; set; }
    }
}
