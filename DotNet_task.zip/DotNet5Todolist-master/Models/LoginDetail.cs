﻿using System;
using System.Collections.Generic;

#nullable disable

namespace DotNet5Crud.Models
{
    public partial class LoginDetail
    {
        public int id { get; set; }
        public string username { get; set; }
        public string password { get; set; } 
    }
}
