﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace DotNet5Crud.Models
{
    public partial class CompanyDBContext : DbContext
    {
        public CompanyDBContext(DbContextOptions<CompanyDBContext> options)
            : base(options)
        {
        }
        public virtual DbSet<Todolist> Todolists { get; set; }
        public virtual DbSet<LoginDetail> LoginDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LoginDetail>(entity =>
            {
                entity.Property(e => e.username)
                    .HasMaxLength(250)
                    .IsUnicode(false);
                entity.Property(e => e.password)
                    .HasMaxLength(250)
                    .IsUnicode(false);
            });
            modelBuilder.Entity<Todolist>(entity =>
            {
                entity.Property(e => e.Details)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
