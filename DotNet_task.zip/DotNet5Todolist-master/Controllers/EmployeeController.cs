﻿using DotNet5Crud.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace DotNet5Crud.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly CompanyDBContext _context;

        public EmployeeController(CompanyDBContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> LIndex(string Name,string Id)
        {
            if (Name != null && Id!=null)
            {
                var UserExist = await _context.LoginDetails.Where(e => e.username == Name).Where(el => el.password == Id).ToListAsync();
                //return View(todolist);
                if (UserExist.Count>0)
                {
                    //var todolist = await _context.Todolists.Where(e => "Admin" == Name).Where(el => "admin" == Id).ToListAsync();
                    var todolist = await _context.Todolists.ToListAsync();
                    return View(todolist);
                }
                else
                {
                    return NotFound();
                }
            }
            else
            {
                return NotFound();
            }
            
        }
        public async Task<IActionResult> Index()
        {
           
                var todolist = await _context.Todolists.ToListAsync();
                return View(todolist);
            

        }

        public async Task<IActionResult> Login()
        {
            var todolist = await _context.Todolists.ToListAsync();
            return View();
        }


        //AssignCourse Get Method
        public async Task<IActionResult> AssignCourse(int? Id)
        {
            ViewBag.PageName = Id == null ? "Create new entry" : "Edit entry";
            ViewBag.IsEdit = Id == null ? false : true;
            if (Id == null)
            {
                return View();
            }
            else
            {
                var todolist = await _context.Todolists.FindAsync(Id);

                if (todolist == null)
                {
                    return NotFound();
                }
                return View(todolist);
            }        
        }

        //AddOrEdit Get Method
        public async Task<IActionResult> AddOrEdit(int? Id)
        {
            ViewBag.PageName = Id == null ? "Create new entry" : "Edit entry";
            ViewBag.IsEdit = Id == null ? false : true;
            if (Id == null)
            {
                return View();
            }
            else
            {
                var todolist = await _context.Todolists.FindAsync(Id);

                if (todolist == null)
                {
                    return NotFound();
                }
                return View(todolist);
            }
        }


        //AddOrEdit Post Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOrEdit(int Id, [Bind("Id,Name,Details,LastUpdate")]
        Todolist todolistData)
        {
            bool IsTodolistExist = false;

            Todolist todolist = await _context.Todolists.FindAsync(Id);

            if (todolist != null)
            {
                IsTodolistExist = true;
            }
            else
            {
                todolist = new Todolist();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    todolist.Name = todolistData.Name;
                    todolist.Details = todolistData.Details;
                    todolist.LastUpdate = System.DateTime.UtcNow;

                   if(IsTodolistExist)
                    {
                        _context.Update(todolist);
                    }
                    else
                    {
                        _context.Add(todolist);
                    }                   
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(todolistData);
        }

        // Employee Details
        public async Task<IActionResult> Details(int? Id)
        {
            if (Id == null)
            {
                return NotFound();
            }
            var todolist = await _context.Todolists.FirstOrDefaultAsync(m => m.Id == Id);
            if (todolist == null)
            {
                return NotFound();
            }
            return View(todolist);
        }

        // GET: Employees/Delete/1
        public async Task<IActionResult> Delete(int? Id)
        {
            if (Id == null)
            {
                return NotFound();
            }
            var todolist = await _context.Todolists.FirstOrDefaultAsync(m => m.Id == Id);

            if (todolist == null)
            {
                return NotFound();
            }

            return View(todolist);
        }

        // POST: Employees/Delete/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int Id)
        {
            var todolist = await _context.Todolists.FindAsync(Id);
            _context.Todolists.Remove(todolist);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

    }
}
